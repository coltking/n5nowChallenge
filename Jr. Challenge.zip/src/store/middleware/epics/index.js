import { combineEpics } from "redux-observable";

const rootEpic = combineEpics();

export default rootEpic;
